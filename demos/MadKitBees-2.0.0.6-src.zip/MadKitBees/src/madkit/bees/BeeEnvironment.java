/*
 * Copyright 1997-2011 Fabien Michel, Olivier Gutknecht
 * 
 * This file is part of MadKit_Bees.
 * 
 * MadKit_Bees is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MadKit_Bees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MadKit_Bees. If not, see <http://www.gnu.org/licenses/>.
 */
package madkit.bees;

import java.awt.Dimension;
import java.util.logging.Level;

import madkit.kernel.Watcher;

/**
 * @version 2.0.0.2
 * @author Fabien Michel
 */
public class BeeEnvironment
{
	Dimension envSize;

	int queenMaxAcc;
    int queenMaxVel;
    int beeMaxAcc;
    int beeMaxVel;

    public int getWidth(){return envSize.width;}
    public int getHeight(){return envSize.height;}
    public void setQueenAcceleration (int add){queenMaxAcc = add;}
    public int getQueenAcceleration(){return queenMaxAcc;}
    public void setQueenVelocity (int add){queenMaxVel = add;}
    public int getQueenVelocity(){return queenMaxVel;}
    public void setBeeAcceleration(int add){beeMaxAcc = add;}
    public int getBeeAcceleration(){return beeMaxAcc;}
    public void setBeeVelocity (int add){beeMaxVel = add;}
    public int getBeeVelocity(){return beeMaxVel;}
    

public BeeEnvironment()
{
    queenMaxAcc=5;
    queenMaxVel=12;
    beeMaxAcc=3;
    beeMaxVel=9;
}

/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "Bee env : size = "+envSize;
}

/**
 * @param envSize
 */
public BeeEnvironment(Dimension envSize) {
	this();
	this.envSize = envSize;
}

/**
 * @param envSize the envSize to set
 */
public final void setEnvSize(Dimension envSize) {
	this.envSize = envSize;
}
}

