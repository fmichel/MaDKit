package rendezVous;

import javax.swing.JOptionPane;




//Classe permettant de creer des fen�tres pour rentrer des choix
public class FenetreInput {


	public String nombreagent(){ // fen�tre du choix de nombre d'agent par session
	return JOptionPane.showInputDialog("nombre d'agent(s)");
	}
	
	
	
	public int reco(){ //methode qui permet de savoir si l'utilisateur veut faire une nouvelle session
		return JOptionPane.showConfirmDialog(null, "Nouvelle session?");
	}
}
