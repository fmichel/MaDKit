/*
 * Copyright 1997-2011 Fabien Michel, Olivier Gutknecht
 * 
 * This file is part of MadKit_Bees.
 * 
 * MadKit_Bees is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MadKit_Bees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MadKit. If not, see <http://www.gnu.org/licenses/>.
 */
package madkit.bees;

import java.awt.Point;
import java.util.logging.Level;

import madkit.kernel.Message;
import madkit.messages.ObjectMessage;
import static madkit.bees.BeeLauncher.*;

/**
 * @version 2.0.0.2
 * @author Fabien Michel, Olivier Gutknecht 
*/
public class QueenBee extends AbstractBee
{
	static int border = 20;

	public void buzz()
	{
		Message m = nextMessage();
		if(m != null){
			sendReply(m, new ObjectMessage<BeeInformation>(myInformation));
		}

		super.buzz();

		if (beeWorld != null) {
			// check to see if the queen hits the edge
			final Point location = myInformation.getCurrentPosition();
			if (location.x < border || location.x > (beeWorld.getWidth() - border)) {
				dX = -dX;
				location.x += (dX);
			}
			if (location.y < border	|| location.y > (beeWorld.getHeight() - border)) {
				dY = -dY;
				location.y += (dY);
			}
		if(logger != null){
			logger.fine("my env = "+beeWorld);
			logger.finest(myInformation.getPreviousPosition().toString());
			logger.finest(myInformation.getCurrentPosition().toString());
		}
	}
	}

	public void activate()
	{
		requestRole(COMMUNITY,SIMU_GROUP,QUEEN_ROLE,null);
		requestRole(COMMUNITY,SIMU_GROUP,BEE_ROLE,null);
		broadcastMessage(COMMUNITY,SIMU_GROUP,FOLLOWER_ROLE, new ObjectMessage<BeeInformation>(myInformation));
		BeeViewer.nbOfBroadcast++;
		if(logger != null)
			logger.info("my initial location"+myInformation.getCurrentPosition());
	}

	/* (non-Javadoc)
	 * @see madkit.kernel.AbstractAgent#end()
	 */
	@Override
	protected void end() {
		//informing follower that I am leaving
		BeeViewer.nbOfBroadcast++;
		broadcastMessage(COMMUNITY,SIMU_GROUP,FOLLOWER_ROLE, new ObjectMessage<BeeInformation>(myInformation));
	}

	/* (non-Javadoc)
	 * @see madkit.demos.bees.AbstractBee#getMaxVelocity()
	 */
	@Override
	protected int getMaxVelocity() {
		if (beeWorld != null) {
			return beeWorld.getQueenVelocity();
		}
		return 0;

	}

	/* (non-Javadoc)
	 * @see madkit.demos.bees.AbstractBee#computeNewVelocities()
	 */
	@Override
	protected void computeNewVelocities() {
		if (beeWorld != null) {
			dX += randomFromRange(beeWorld.getQueenAcceleration());
			dY += randomFromRange(beeWorld.getQueenAcceleration());
		}
	}


}
