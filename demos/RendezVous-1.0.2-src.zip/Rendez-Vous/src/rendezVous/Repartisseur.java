package rendezVous;


import javax.swing.JOptionPane;

import madkit.kernel.Agent;
import madkit.kernel.Message;
import madkit.message.ObjectMessage;
import madkit.message.XMLMessage;


// Agent qui permet de lancer des sessions oe le nombre d'agent est donne par l'utilisateur

public class Repartisseur extends Agent {
	
	//--------------------------------Variables ---------------------------------------------------------------------------------
	String myCommunity="Communaute"; // groupe, role et comunaute
	String myGroup="groupe1";
	String myRole="repartisseur";
	String[] nomsagents; // tableau contenant le nom de tout les agents
	
	int numagent=0; // numero attribue aux agents choisisseurs

	String agents=""; boolean anul=false;// au cas ou on appui sur "annuler" au nombres d'agent
	
	int y=0; // indice du bon jour pour le rendez vous
	int tab[]; // pour receptionner le talbeau de contraintes fnal
	
	int nombreagent; // Nombre d'agent a lancer a chaque session

	boolean partiecomm=true; // variable qui permet de decider quand lancer la prochaine session
	
	boolean alive=true; // Variable qui permet d'arreter le programme
	
	FenetreInput fen = new FenetreInput(); //la fenetre pour decider du nombre d'agent a chaque session
	
	Fenetre f=new Fenetre(this);  //la fenetre 
	//-----------------------------------------------------------------------------------------------------------------


	
	public void activate() // e la creation du repartisseur
	{
		
		
//-------------------------------- Creation groupe et Role---------------------------------
		
	//	while(nextMessage()!=null)nextMessage(); 
createGroupIfAbsent("Communaute","groupe1" ,true); // creation du groupe si c'est la 1ere session
		requestRole(myCommunity,myGroup,myRole); // prendre le role de repartisseur
		
//----------------------------------------------------------------------------------------
		}
	
	
	
	
	
	public void live() // la vie du repartisseur
	{
		
		while(alive){ //debut programme
			
			if(anul==false){ // si la session n'a pas ete finit
//------------------- Choix nombre d'agents --------------------------------------------------------------------------
			nombreagent=0;
			while(nombreagent<=0){ // redemande le nombre d'agent si on indique 0 ou moins, ou si on ne met rien
			agents=(fen.nombreagent()); // fenetre du choix du nombre d'agents
			if(agents!=null){
			nombreagent=Integer.parseInt(agents);} // Met le nombre d'agent au nombre indique
			else {nombreagent=1;alive=false;partiecomm=false;anul=true;}// ferme le programme si on met "annuler"
			} 
//--------------------------------------------------------------------------------------------------------------------
			
			
			
			if(anul==false){ // si la session n'a pas ete finit
				
				
			
				 // lancement des agents
				nomsagents=new String[nombreagent];	
		for(int i=0;i<nombreagent;i++)
		{ launchAgent(new Agenda1(),1,false); 	
		 numagent++;
			broadcastMessage(myCommunity, myGroup,"Independant", new XMLMessage("Agent"+String.format("%d",numagent)));
		
		}
				
//------------------ Attente remplissage contraintes par 'utilisateur ---------------------------------
		
		int nb=nombreagent;//variable qui sert e attendre que toutes les contraintes des agents soient rentrees
		while(nb!=0)// attente que tout les agents ait envoye un message
		{

			Message m=waitNextMessage();
			nb--;
			
			if(m.toString().equals("je meurs"))nombreagent--; // si un agent meurt le nombre d'agent est diminue
			}
//----------------------------------------------------------------------------------------------------------------------
		
		
		
		
//---------------------------------- Attente lancement par l'utilisateur -------------------------------
		f.attente(true);			 // indique a la fenetre que le repartisseur attends un appui de touche
			f.ajoutSortieLigne(" APPUYEZ SUR LE BOUTON POUR CONTINUER"); 
		while(f.go==false){System.out.print(""); } // attente de l'appui de touche
	envoiTous(myCommunity, myGroup, new XMLMessage("Commencez")); //permet aux agents choisisseur de commencer 
		f.attente(false);// indique a la fenetre que le repartisseur n'attends plus un appui de touche
//------------------------------------------------------------------------------------------------------
			
			
			
			
		y=0; // variable qui verifie si il y a une solution dans les contraintes finales 
		//(y sera l'indice de la bonne solution)
		
		// envoi aux agents choisisseurs le nombre de leur partenaire
		envoiTous(myCommunity, myGroup, new XMLMessage(String.format("%d", nombreagent))); 
		
		
		
		
//---------------------------- attente remplissage contraintes de roles par les agents-----------------------
		f.ajoutSortieLigne("**** Calcul en cours *****");
		
			Message messdebut = null; // reception messages de commencement des agents
			for(int i=0;i<nombreagent;i++)
			{
				 messdebut = waitNextMessage();
				 
				 if ( messdebut.toString().equals("je meurs")) 
				 { // s'il n'y a plus d'agent en vie, le programme s'arrete
					 f.ajoutSortieLigne(" un agent a ete tue");nombreagent=nombreagent-1; 
					if(nombreagent<=0){alive=false;break; }
				
			}}		
//--------------------------------------------------------------------------------------------------------------
			
			if(alive) // s'il reste des agents en vie
			{
				
			envoiRandom(new XMLMessage("depart calcul")); // fait demarrer le calcul
			
			
			
			Message m = null; // reception messages des agents
//-------------------------- Reception messages des agents --------------------------------------------
		while(!(m instanceof ObjectMessage))  // attente reponse finale
		{ 
		 m = waitNextMessage();  // reception
		
		if (m.toString().equals("je meurs")) 
		{// s'il n'y a plus d'agent en vie, le programme s'arrete
			f.ajoutSortieLigne(" un agent a ete tue");nombreagent=nombreagent-1;  
	if(nombreagent<=0){alive=false;break; }
		}
		if(m instanceof ObjectMessage){ 
			envoiTous(myCommunity, myGroup, new XMLMessage("fin calcul"));
			tab=  (int[]) ((ObjectMessage) m).getContent(); // reception du tableau de contraintes finales
		}}
//----------------------------------------------------------------------------------------
	
		 
		
		
	
			if(alive){ // s'il reste des agents en vie
				
				
			if(y<14){// regarde s'il y a une case du talbeau des contraintes finales e 0 (tous present)
			while( y<14 && tab[y]!=0) { 
				
				y++;if(y>=14)break;
			}}
			
			while(nextMessage()!=null)nextMessage();     // libere tout les messages reeus
			
			
			
//-----------------------------------s'il n'y a pas de solutions---------------------------------------------------------
			if(y==14){     
	
				f.ajoutSortieLigne("Pas de jour/heure correspondant");
			//variables pour determiner la case ayant la valeur la plus petite 
			//(dependant du nombre et importance des agents e la periode)
			int min=tab[0];
			int indice=0;
			for(int j=1;j<14;j++)
			{
				if(tab[j]<min){min=tab[j];indice=j;}   // recupere l'indice de la valeur minimum
			}	
			// envoi l'indice aux agent pour qu'ils regargent s'ils sont concernes
			envoiTous(myCommunity, myGroup, new ObjectMessage(indice)); 
			f.ajoutSortieLigne("les agents bannis et perturbes sont : ");
			XMLMessage agentpasbon; // message qui receptionne les agents bannis
			for(int i=0;i<nombreagent;i++)
			{
			agentpasbon=(XMLMessage) waitNextMessage();if(agentpasbon.toString().equals("je meurs"))i--; 
			if(!agentpasbon.toString().equals("pas moi") && !agentpasbon.toString().equals("je meurs") && !agentpasbon.toString().contains("perturbe")) 
			{// si le message contient le nom d'un agent
				
			f.ajoutSortieLigne(agentpasbon.toString()+" est banni"); // indique a l'utilisateur les agents banni
			if(!agentpasbon.toString().contains("Independant")) 
				// indique a l'utilisateur les agents perturbe
				f.ajoutSortieLigne("les "+agentpasbon.getSender().getRole()+"s sont perturbes e cause d'un agent de leur rele absent");

			}
				else{ if(!agentpasbon.toString().equals("pas moi") && !agentpasbon.toString().equals("je meurs")){
					f.ajoutSortieLigne(agentpasbon.toString());
				}
				}					
			}	
			y=indice; // le bon jour est celui oe la valeur du tableau des contrainte est la plus petite
			}
//-----------------------------------------------------------------------------------------------------------------------			
			else { // s'il y a une solution
				// debloque les agents qui attendent l'indice a verifier
				envoiTous(myCommunity, myGroup, new XMLMessage("meurs")); 
	
			}
			
			
			
			 f.ajoutSortieLigne("Le bon jour est : "); 

			
			
			
			
//------------------------------ affichage de la date la plus rapide-----------------------------------
			switch (y) 
			{ 
			case 0: f.ajoutSortieLigne("Lundi matin ! "); break; 
			case 1: f.ajoutSortieLigne("Lundi aprem ! "); break; 
			case 2: f.ajoutSortieLigne("Mardi matin ! "); break; 
			case 3: f.ajoutSortieLigne("Mardi aprem ! "); break; 
			case 4: f.ajoutSortieLigne("Mercredi matin ! "); break; 
			case 5: f.ajoutSortieLigne("Mercredi aprem ! "); break; 
			case 6: f.ajoutSortieLigne("Jeudi matin ! "); break; 
			case 7: f.ajoutSortieLigne("Jeudi aprem ! "); break; 
			case 8: f.ajoutSortieLigne("Vendredi matin ! "); break; 
			case 9: f.ajoutSortieLigne("Vendredi aprem ! "); break; 
			case 10: f.ajoutSortieLigne("Samedi matin ! "); break; 
			case 11: f.ajoutSortieLigne("Samedi aprem ! "); break; 
			case 12: f.ajoutSortieLigne("Dimanche matin ! "); break; 
			case 13: f.ajoutSortieLigne("Dimanche aprem ! "); break; 
			
			
			default: break;
			}}
//----------------------------------------------------------------------------------------------------------------
			
			
			
anul=true;f.fin.setEnabled(true); // fait boucler le repartisseur et rend le bouton fin disponible
		}}
			
		}	
			anul=true; System.out.print("");
			}
//------------------------- Si alive est passe e false --------------------------------------------------
		envoiTous(myCommunity, myGroup,new Message()); // libere les agents en attente
		f.dispose(); // detruit la fenetre
		this.killAgent(this,0);  // termine le le repartisseur en cours
//-------------------------------------------------------------------------------------------------------
		}
		
		 
	
	// envoi e un des reles (le premier e qui envoyer n'a pas d'importance) s'il existe
	private void envoiRandom(XMLMessage mess) 
	{ 
		if(isRole(myCommunity,myGroup,"Informaticien"))sendMessage(myCommunity,myGroup,"Informaticien", mess);
		else if(isRole(myCommunity,myGroup,"Economiste"))sendMessage(myCommunity,myGroup,"Economiste", mess);
		else if(isRole(myCommunity,myGroup,"Ressources Humaines"))sendMessage(myCommunity,myGroup,"Ressources Humaines", mess);
		else if (isRole(myCommunity,myGroup,"Electricien"))sendMessage(myCommunity,myGroup,"Electricien", mess);
		else if (isRole(myCommunity,myGroup,"Cuisinier"))sendMessage(myCommunity,myGroup,"Cuisinier", mess);
		else if(isRole(myCommunity,myGroup,"Independant"))sendMessage(myCommunity,myGroup,"Independant", mess);
	}





	public void end(){// La mort du repartisseur
	
	f.dispose(); // detruit la fenetre
		this.killAgent(this,0); // tue l'agent
		
	}
	
	public void recommencer()
	{
		
		int result = fen.reco();
		//------------------- Recomencement ------------------------------------------------------------------------------
		if(result == JOptionPane.YES_OPTION){ // si l'utilisateur veut une nouvelle session
			leaveRole(myCommunity, myGroup,"repartisseur"); //quitte le role
			launchAgent(new Repartisseur(),1,false);	// lancement d'un nouveau repartisseur
			alive=false;
	}
		else if(result == JOptionPane.NO_OPTION){
			alive=false;
//			System.exit(0);
		}

	
       //------------------------------------------------------------------------------------------------------------
		
		
		
	}




public void envoiTous (String community, String Group, Message mess) // envoi message e tout le monde
{
	
	broadcastMessage(myCommunity, myGroup,"Independant", mess);
	broadcastMessage(myCommunity, myGroup,"Informaticien", mess);
	broadcastMessage(myCommunity, myGroup,"Economiste", mess);
	broadcastMessage(myCommunity, myGroup,"Ressources Humaines", mess);
	broadcastMessage(myCommunity, myGroup,"Electricien", mess);
	broadcastMessage(myCommunity, myGroup,"Cuisinier", mess);
	broadcastMessage(myCommunity, myGroup,"Independant finit", mess);
}



	}

