/**
 * 
 */
package template;

import java.util.logging.Level;

import madkit.kernel.Agent;
import madkit.kernel.Madkit;

/**
 * A simple agent that lives 10 seconds and quit
 * @author Fabien Michel
 *
 */
public class HelloWorldAgent extends Agent {

	/**
	 * This behavior is the first to be activated.
	 * @see madkit.kernel.AbstractAgent#activate()
	 */
	@Override
	protected void activate() {
		//This is the finest log level: The agent will log each of its actions
		setLogLevel(Level.FINEST);
		
		createGroup("myCommunity", "myGroup");
		requestRole("myCommunity", "myGroup", "hello agent");
	}
	
	/**
	 * This behavior implements the life of the agent. 
	 * It is usually a while true loop.
	 * @see madkit.kernel.Agent#live()
	 */
	@Override
	protected void live() {
		int nb=10;
		while (nb-- > 0) {
			if(logger != null)
				logger.info("Hello, I will quit in "+nb+" seconds");
			pause(1000);
		}
	}
	
	/**
	 * This behavior is called when the agent has finished its live behavior.
	 * @see madkit.kernel.AbstractAgent#end()
	 */
	@Override
	protected void end() {
		if(logger != null)
			logger.info("Bye bye !");
	}
	
	/**
	 * Implementing a main method is not required at all but it could be used 
	 * to simulate a command line call to MadKit with the desired options inside an IDE.
	 * @param args
	 */
	public static void main(String[] args) {
		String[] argss = {"--agentLogLevel","ALL", //Everything will be log
				"--defaultWarningLogLevel","INFO", //The level at which warnings appear when an action of an agent has failed
				"--launchAgents",HelloWorldAgent.class.getName()+",true"}; //The agents to launch, and with a GUI
		
		Madkit.main(argss);
	}

}
