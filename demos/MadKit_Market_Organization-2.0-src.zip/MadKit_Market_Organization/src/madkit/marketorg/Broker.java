/*
 * Broker.java - Travel, a simple demo application
 * Copyright (C) 1998-2007 Olivier Gutknecht, Jacques Ferber
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package madkit.marketorg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import madkit.gui.OutputPanel;
import madkit.kernel.Agent;
import madkit.kernel.AgentAddress;
import madkit.kernel.Madkit;
import madkit.kernel.Message;
import madkit.messages.ACLMessage;
import madkit.messages.ObjectMessage;

/**
 * @author Fabien Michel
 * @since MadKit 5.0.0.8
 * @version 0.9
 * 
 */
public class Broker extends Agent
{

	static private int nbOfBrokersOnScreen=0;
	private JPanel blinkPanel;
	public static List<String> availableTransports = Arrays.asList("train","boat","plane","bus");

	public void activate()
	{
		createGroupIfAbsent("travel","travel-clients",true,null);
		createGroupIfAbsent("travel","travel-providers",true,null);
		requestRole("travel","travel-providers", "broker",null);
		requestRole("travel","travel-clients", "broker",null);
	}


	public void live()
	{
		while (true)
		{
			Message m;
			m = getMostRecentMessage();
			if (m == null) {
				m = waitNextMessage();
			}
			String role = m.getSender().getRole();
			if(role.equals("client")){
				handleClientRequest((ObjectMessage<String>) m);
			}
		}
	}

	private void handleClientRequest(ObjectMessage<String> request) {
		if(! request.getSender().exists())
			return;
		if (blinkPanel != null) {
			blinkPanel.setBackground(Color.YELLOW);
		}
		if(logger != null)
			logger.info("I received a request for a "+request.getContent()+" \nfrom "+request.getSender());
		List<Message> bids = broadcastMessageWithRoleAndWaitForReplies(
				"travel",
				"travel-providers",  
				request.getContent()+"-provider",
				new ObjectMessage<String>("make-bid-please"),
				"broker",
				900);
		if(bids == null){
			if(logger != null)
				logger.info("No bids at all !!");
			if (blinkPanel != null) {
				blinkPanel.setBackground(Color.LIGHT_GRAY);
			}
			return;
		}
		Message m = selectBestBid(bids);
		if (m != null) {
			if(logger != null)
				logger.info("There is one interesting offer from "+m.getSender());
			String contractGroupId = ""+System.nanoTime();
			Message ack = sendMessageWithRoleAndWaitForReply(
					m.getSender(),
					new ObjectMessage<String>(contractGroupId), 
					"broker",
					1000);
			if(ack == null){
				if(logger != null)
					logger.info("Provider disappears !!");
				return;
			}
			if(logger != null)
				logger.info("Provider is ready !\nSending the contract number to client");
			sendReply(request, new ObjectMessage<String>(contractGroupId)); 
			pause((int) (Math.random()*2000+1000));//let us celebrate !!
		}
		if (blinkPanel != null) {
			blinkPanel.setBackground(Color.LIGHT_GRAY);
		}
	}



	private Message selectBestBid(List<Message> bids) {
		ObjectMessage<Integer> best = (ObjectMessage<Integer>) bids.get(0);
		for(Message m : bids){
			ObjectMessage<Integer> offer = (ObjectMessage<Integer>) m;
			if(best.getContent() > offer.getContent()){
				best = offer;
			}
		}
		return best;
	}

	@Override
	public void setupFrame(JFrame frame) {
		JPanel p = new JPanel(new BorderLayout());
		//customizing but still using the OutputPanel from MadKit GUI
		p.add(new OutputPanel(this),BorderLayout.CENTER);
		blinkPanel = new JPanel();
		blinkPanel.add(new JLabel(new ImageIcon(getClass().getResource("images/broker.png"))));
		p.add(blinkPanel,BorderLayout.NORTH);
		blinkPanel.setBackground(Color.LIGHT_GRAY);
		p.validate();
		frame.add(p);
		int xLocation = nbOfBrokersOnScreen*390 > Toolkit.getDefaultToolkit().getScreenSize().getWidth() ? (int) (Math.random()*900) : nbOfBrokersOnScreen*390;
		nbOfBrokersOnScreen++;
		frame.setLocation(xLocation, 320);
		frame.setSize(390, 300);
	}

}







