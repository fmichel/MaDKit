/*
 * Copyright 1997-2011 Fabien Michel, Olivier Gutknecht
 * 
 * This file is part of MadKit_Bees.
 * 
 * MadKit_Bees is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MadKit_Bees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MadKit_Bees. If not, see <http://www.gnu.org/licenses/>.
 */
package madkit.bees;

import java.util.logging.Level;

import madkit.kernel.Scheduler;
import madkit.simulation.GenericBehaviorActivator;
import static madkit.bees.BeeLauncher.*;

/**
 * @version 2.0.0.2
 * @author Fabien Michel, Olivier Gutknecht 
*/
public class BeeScheduler extends madkit.kernel.Scheduler
{
	
	private String community;

	BeeScheduler(String community){
		this.community = community;
	}

 public void activate()
  {
	 super.activate();
	 	setLogLevel(Level.OFF);
      requestRole("buzz",SIMU_GROUP,SCHEDULER_ROLE,null);
      addActivator(new GenericBehaviorActivator<AbstractBee>(community,SIMU_GROUP,BEE_ROLE,"buzz"));
      addActivator(new GenericBehaviorActivator<BeeViewer>(community,SIMU_GROUP,"bee observer","observe"));
      setDelay(20);
      setSimulationState(Scheduler.State.RUNNING);
  }
 
 
 /* (non-Javadoc)
 * @see madkit.kernel.Scheduler#doSimulationStep()
 */
//@Override
//public void doSimulationStep() {
//	long time = System.nanoTime();
//	super.doSimulationStep();
//	time = System.nanoTime() - time;
//	System.err.println(time);
//}

}
