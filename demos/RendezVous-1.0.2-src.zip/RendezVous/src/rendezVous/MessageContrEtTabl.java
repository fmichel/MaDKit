package rendezVous;

public class MessageContrEtTabl { // type de message envoy�s par les agents avec en m�me temps le tableaux de contraintes 
								  //et le tableau a qui ne pas envoyer le message
	
	int[] contraintes;
	boolean[] Nepasenvoi;
	
	public  MessageContrEtTabl(int[] contraintes,boolean[] Nepasenvoi) {
	
		this.contraintes=contraintes;
	this.Nepasenvoi=Nepasenvoi;
	}
	
}
