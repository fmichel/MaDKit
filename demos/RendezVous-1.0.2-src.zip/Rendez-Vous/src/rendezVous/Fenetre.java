package rendezVous;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

/*

Fenetre du r�partisseur

*/

public class Fenetre extends JFrame implements ActionListener{ 

	boolean go=false; // booleen qui lance le r�partisseur si les conditions sont r�unis

	
	JTextArea sortie=new JTextArea(100,1000) ; // le texte
	
JButton lancement=new JButton ("Lancer");   // un bouton pour lancer
JButton fin=new JButton ("Fin");           // un bouton pour finir ou recommencer

Repartisseur repartisseur;               // pour lancer la lafin du r�partisseur si on appui sur boutton fin
	
	
	public Fenetre( Repartisseur repartisseur)
	{
		 this.repartisseur=repartisseur;
		
		 setSize(500,500);          								 // taille fenetre
		 setTitle("Repartisseur");								    // son titre
		 JLabel placebouton = new JLabel("");                      // un jlabel pour placer le bouton  
		 placebouton.setPreferredSize(new Dimension(300, 100));   // changement taille label
		 getContentPane().add( placebouton, BorderLayout.SOUTH); // parametres pour placer un bouton
	
		lancement.setEnabled(false); // bouton pas cliquable au d�part
		fin.setEnabled(false);      // bouton pas cliquable au d�part
		
		lancement.setBounds(0, 0, 300, 50); // changement taille  boutons
		fin.setBounds(300, 0, 150, 50);
		
		add(sortie);                 //  ajout du texte � la fen�tre
		placebouton.add(lancement); // ajout du bouton lancement
		placebouton.add(fin);      // ajout du bouton fin

		setVisible(true);

		lancement.addActionListener(this); // place un �couteur sur le bouton lancement
		fin.addActionListener(this);      // place un �couteur sur le bouton fin
	}
	
	
	public void ajoutSortieLigne (String s) // affichage dans la fenetre du texte
	{
		sortie.append(s+"\n");
		sortie.setCaretPosition(sortie.getDocument().getLength());
	}

	
	public void attente(boolean a) // changer le fait que le bouton soit cliquable ou pas
	{
		lancement.setEnabled(a);
	}

	public void actionPerformed(ActionEvent arg0) { 
		if(arg0.getSource() == lancement)// si le bouton lancer est appuy� , go (le booleen) est modifi�
			{
				this.go=true;
			}
		else // si on appui sur terminer
		{
			repartisseur.recommencer();
			
		}
	}
	
	

	
}
