/*
 * Copyright 1997-2011 Fabien Michel, Olivier Gutknecht
 * 
 * This file is part of MadKit_Bees.
 * 
 * MadKit_Bees is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MadKit_Bees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MadKit_Bees. If not, see <http://www.gnu.org/licenses/>.
 */
package madkit.bees;

import static madkit.bees.BeeLauncher.BEE_ROLE;
import static madkit.bees.BeeLauncher.LAUNCHER_ROLE;
import static madkit.bees.BeeLauncher.SIMU_GROUP;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;

import madkit.gui.GUIToolkit;
import madkit.kernel.Probe;
import madkit.kernel.Watcher;
import madkit.messages.ObjectMessage;
import madkit.simulation.PropertyProbe;

/**
 * @version 2.0.0.2
 * @author Fabien Michel, Olivier Gutknecht 
 */
public class BeeViewer extends Watcher {

	private BeeEnvironment environment;
	private JPanel display;
	private AbstractAction synchroPaint,artMode,randomMode,launch,trailModeAction;
	private PropertyProbe<AbstractBee,BeeInformation> beeProbe;
	private BeeScheduler sch;
	private Probe<AbstractBee> probe;
	private int total = 0;
	private String community;
	public static int nbOfBroadcast = 0;

	public BeeViewer(BeeScheduler beeScheduler, String COMMUNITY_ID) {
		community = COMMUNITY_ID;
		sch = beeScheduler;
		setLogLevel(Level.OFF);
		environment = new BeeEnvironment(new Dimension(1600,1024));
	}

	@Override
	protected void activate()
	{
		requestRole(community,SIMU_GROUP,"bee observer");
		beeProbe = new PropertyProbe<AbstractBee, BeeInformation>(community,SIMU_GROUP,BEE_ROLE,"myInformation"){
			@Override
			public void adding(AbstractBee bee) {
				super.adding(bee);
				bee.setEnvironment(environment);
			}
			@Override
			public void adding(List<AbstractBee> l) {
				super.adding(l);
				for (AbstractBee abstractBee : l) {
					abstractBee.setEnvironment(environment);
				}
			}
		};
		
		probe = new Probe<AbstractBee>(community,SIMU_GROUP,BEE_ROLE){
			public void adding(AbstractBee bee) {
					bee.setEnvironment(environment);
			}
		};
//		addProbe(probe);
//		buildGUI();
		if(logger != null)
			logger.info("ENV is "+environment);
		addProbe(beeProbe);
	}
	
	@Override
	protected void end() {
		removeProbe(beeProbe);
		sendMessage(community, SIMU_GROUP, LAUNCHER_ROLE, new ObjectMessage<String>("SHUTDOWN"));
		killAgent(sch);
		leaveRole(community,SIMU_GROUP,"bee observer");
	}
	
	public void observe()
	{
		if(! (display.isVisible() && isAlive()))
			return;
		if ((Boolean) synchroPaint.getValue(Action.SELECTED_KEY)) {
			try {
				SwingUtilities.invokeAndWait(new Runnable() {
					@Override
					public void run() {
						display.paintImmediately(0, 0, display.getWidth(), display.getHeight());
					}
				});
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
		}
		else
			display.repaint();
	}

	public void paintBees(Graphics g){
if (g != null) {
	//		total += nbOfBroadcast * beeProbe.size();
	//		nbOfBroadcast = 0;
	//		g.drawString("about "+total+" messages have been exchanged ", 10, 25);
	computeFromInfoProbe(g);
	//		computeFromGenericProbe(g);
}
	}

//	private void computeFromGenericProbe(Graphics g) {
//		g.drawString("You are watching "+probe.size()+" MadKit agents", 10, 10);
//		for (AbstractBee bee : probe.getCurrentAgentsList()) {
//			BeeInformation b = bee.myInformation;
//			g.setColor(b.getBeeColor());
//			final Point p = b.getCurrentPosition();
//			if ((Boolean) trailModeAction.getValue(Action.SELECTED_KEY)) {
//				final Point p1 = b.getPreviousPosition();
//				g.drawLine(p1.x, p1.y, p.x, p.y);
//			}
//			//unexplainable mode
//			//				if(true){
//			//					g.fillOval(p.x, p.y,p.x, p.y);
//			//				}
//			else{
//				g.drawLine(p.x, p.y, p.x, p.y);
//			}
//		}
//	}

	private void computeFromInfoProbe(Graphics g) {
		g.drawString("You are watching "+beeProbe.size()+" MadKit agents", 10, 10);
		final Collection<BeeInformation> info = beeProbe.getAllProperties();
		Color lastColor = null;
		int threshold = beeProbe.size()/75000 + 1;
		int i =0;
		for(final BeeInformation b : info){
			if (i++ % threshold != 0) {
				continue;
			}
			Color c = b.getBeeColor();
			if(c != lastColor){
				lastColor = c;
				g.setColor(lastColor);
			}
//			g.setColor(b.getBeeColor());
			final Point p = b.getCurrentPosition();
			if ((Boolean) trailModeAction.getValue(Action.SELECTED_KEY)) {
				final Point p1 = b.getPreviousPosition();
				g.drawLine(p1.x, p1.y, p.x, p.y);
			}
			//unexplainable mode
			//				if(true){
			//					g.fillOval(p.x, p.y,p.x, p.y);
			//				}
			else{
				g.drawLine(p.x, p.y, p.x, p.y);
			}
		}
	}
	
	@Override
	public void setupFrame(JFrame frame) {
		buildActions(frame);
		frame.setBackground(Color.black);
		JMenuBar jmenubar = new JMenuBar();
		jmenubar.add(GUIToolkit.createLaunchingMenu(this));
		jmenubar.add(GUIToolkit.createLogLevelMenu(this));
		jmenubar.add(sch.getSchedulerMenu());
		JMenu options = new JMenu("Options");
		options.add(new JCheckBoxMenuItem(synchroPaint));
		options.add(new JCheckBoxMenuItem(artMode));
		options.add(new JCheckBoxMenuItem(randomMode));
		options.add(new JCheckBoxMenuItem(trailModeAction));
		options.add(launch);
		jmenubar.add(options);

		ActionListener beeLauncher = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getActionCommand().equals("10000000")){
					JOptionPane.showMessageDialog(null, "Wow !! You have a powerfull computer");
					SwingUtilities.invokeLater(new Runnable() {
						@Override
						public void run() {
						}
					});
				}
				sendMessage(community, SIMU_GROUP, LAUNCHER_ROLE, new ObjectMessage<String>("LAUNCH"+e.getActionCommand()));
			}
		};

		JMenu numberOfBees = new JMenu("Number of bees to launch when clicking the icon");
		JMenu launchBees = new JMenu("Launching");
		ButtonGroup g = new ButtonGroup();
		int defaultBeesNb = 10000;
		for(int i = 1000;i <= 100000;i*=10){
			JRadioButtonMenuItem item = new JRadioButtonMenuItem("Launch "+i+" bees at a time");
			JMenuItem it = new JMenuItem("Launch "+i+" bees");
			it.addActionListener(beeLauncher);
			it.setActionCommand(""+i);
			launchBees.add(it);
			item.setActionCommand(""+i);
			if(i == defaultBeesNb)
				item.setSelected(true);
			g.add(item);
			numberOfBees.add(item);
		}
		options.add(numberOfBees);
		jmenubar.add(launchBees);

		frame.setJMenuBar(jmenubar);
		frame.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		display = new JPanel(){
			@Override
			protected void paintComponent(Graphics g) {
				if (! (Boolean) artMode.getValue(Action.SELECTED_KEY)) {
					super.paintComponent(g);
				}
				paintBees(g);
			}
		};
		display.setBackground(Color.BLACK);
		display.setForeground(Color.white);
		frame.add(display);
		display.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				environment.setEnvSize(e.getComponent().getSize());
				if (beeProbe != null) {
					beeProbe.initialize();
				}
			}
		});
		JToolBar tb = new JToolBar();
		addButtonToToolbar(tb,randomMode);
		addButtonToToolbar(tb,artMode);
		addButtonToToolbar(tb,trailModeAction);
		addButtonToToolbar(tb,synchroPaint);
		addButtonToToolbar(tb,launch);
		
		JPanel tools = new JPanel(new FlowLayout(FlowLayout.LEFT));
		tools.add(tb);
		tools.add(sch.getSchedulerToolBar());
		frame.add(sch.getSchedulerStatusLabel(), BorderLayout.SOUTH);
		//		display.getParent().add(tb,BorderLayout.PAGE_START);
		//		display.getParent().add(sch.getSchedulerToolBar(),BorderLayout.PAGE_START);
		display.getParent().add(tools,BorderLayout.PAGE_START);
		frame.setLocationRelativeTo(null);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		frame.setVisible(true);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
	}

	/**
	 * @param tb
	 */
	private void addButtonToToolbar(JToolBar tb, Action a) {
		JToggleButton jt = new JToggleButton(a);
		jt.setText(null);
		tb.add(jt);
	}

	void buildActions(final JFrame frame){
		synchroPaint = new AbstractAction("Synchronous painting"){
			@Override
			public void actionPerformed(ActionEvent e) {
				//				if(logger != null) logger.info("Switching painting mode");
			}
		};
		initActionIcon(synchroPaint, "Paint all the simulation steps: Don't miss any move","synchroPaint");
		artMode = new AbstractAction("Art mode"){
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		};
		initActionIcon(artMode, "A funny painting mode","artMode");
		randomMode = new AbstractAction("Random mode"){
			@Override
			public void actionPerformed(ActionEvent e) {
				sendMessage(community, SIMU_GROUP, LAUNCHER_ROLE, new ObjectMessage<String>("randomMode "+randomMode.getValue(SELECTED_KEY)));
			}
		};
		initActionIcon(randomMode, "Random mode: Randomly launch or kill bees","random");
		randomMode.putValue(Action.SELECTED_KEY, true);

		trailModeAction = new AbstractAction("Trail mode"){
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		};
		initActionIcon(trailModeAction, "Trails mode: display agents with trails or like point particles","trail");
		trailModeAction.putValue(Action.SELECTED_KEY, true);

		launch = new AbstractAction("Launch bees"){
			@Override
			public void actionPerformed(ActionEvent e) {
				launchAgentBucketWithRoles("madkit.bees.Bee", 10000, Arrays.asList("buzz;bees;bee","buzz;bees;follower"));				
			}
		};
		initActionIcon(launch, "Launch some bees","launch");
	}

	private void initActionIcon(AbstractAction a, String description, String actionCommand){
		a.putValue(Action.SELECTED_KEY, false);
		a.putValue(Action.ACTION_COMMAND_KEY, actionCommand);
		a.putValue(AbstractAction.SHORT_DESCRIPTION, description);
		ImageIcon big = new ImageIcon(getClass().getResource("images/bees_"+actionCommand+".png"));
		a.putValue(AbstractAction.LARGE_ICON_KEY, big);
		a.putValue(AbstractAction.SMALL_ICON, new ImageIcon(big.getImage().getScaledInstance(16, 16,Image.SCALE_SMOOTH)));
	}

}