package rendezVous;

public class MessageContrEtImp {
	// classe pour envoyer � ses membres du role ses contraintes et son importance en m�me temps
	
	
	 int[] contraintes;
	 int importance;

	public MessageContrEtImp(int[] contraintes,int importance)
	{
		this.contraintes=contraintes;
		this.importance=importance;
		
	}

}
