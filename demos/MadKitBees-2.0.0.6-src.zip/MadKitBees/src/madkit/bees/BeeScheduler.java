/*
 * Copyright 1997-2011 Fabien Michel, Olivier Gutknecht
 * 
 * This file is part of MadKit_Bees.
 * 
 * MadKit_Bees is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MadKit_Bees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MadKit_Bees. If not, see <http://www.gnu.org/licenses/>.
 */
package madkit.bees;

import java.util.logging.Level;

import madkit.kernel.AbstractAgent;
import madkit.kernel.Activator;
import madkit.kernel.Message;
import madkit.kernel.Scheduler;
import madkit.kernel.Scheduler.State;
import madkit.messages.ObjectMessage;
import madkit.simulation.GenericBehaviorActivator;
import static madkit.bees.BeeLauncher.*;

/**
 * @version 2.0.0.2
 * @author Fabien Michel, Olivier Gutknecht 
 */
public class BeeScheduler extends madkit.kernel.Scheduler
{

	private static final long serialVersionUID = -6881984366833257439L;
	private String community;
	private GenericBehaviorActivator<AbstractBee> bees;
	private GenericBehaviorActivator<BeeViewer> viewer;

	BeeScheduler(String community){
		this.community = community;
	}

	public void activate()
	{
		super.activate();
		setLogLevel(Level.ALL);
		getLogger().setWarningLogLevel(Level.INFO);
		setLogLevel(Level.OFF);
		requestRole("buzz",SIMU_GROUP,SCHEDULER_ROLE,null);
		bees = new GenericBehaviorActivator<AbstractBee>(community,SIMU_GROUP,BEE_ROLE,"buzz");
		addActivator(bees);
		viewer = new GenericBehaviorActivator<BeeViewer>(community,SIMU_GROUP,"bee observer","observe");
		addActivator(viewer);
		setDelay(20);
		setDelay(0);
		//auto starting myself the agent way
		receiveMessage(new ObjectMessage<State>(Scheduler.State.RUNNING));
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void checkMail(Message m) {
		if (m != null) {
			try {
				boolean mutiCore = ((ObjectMessage<Boolean>) m).getContent();
				if (mutiCore) {
					int nbOfCores = Runtime.getRuntime().availableProcessors();
					bees.setMulticore(nbOfCores > 2 ? nbOfCores  : 2);
				}
				else{
					bees.setMulticore(1);
				}
			} catch (ClassCastException e) {
				super.checkMail(m);
			}
		}		 
	}

/* (non-Javadoc)
 * @see madkit.kernel.Scheduler#doSimulationStep()
 */
//@Override
//public void doSimulationStep() {
//	long time = System.nanoTime();
//	super.doSimulationStep();
//	time = System.nanoTime() - time;
//	System.err.println(time);
//}
//public void doSimulationStep() {
//	bees.multicoreExecute();
//	viewer.execute();
//	setGVT(getGVT() + 1);
//}

}
