package rendezVous;
import madkit.kernel.Madkit;


// Classe permettant de lancer le programme (il lance le r�partisseur au d�but)


public class AgendaLauncher {
	

	public static void main(String[] args)
	{//lancement du repartisseur
		String[] argss = {"--launchAgents", "rendezVous.Repartisseur,false,1", "--agentLogLevel", "OFF"}; 
	
		Madkit.main(argss); // lancement madkit
		
	}


	

}
